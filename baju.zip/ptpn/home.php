<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-color: #898684;
        }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HOME</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<!-- Tautan ke Font Awesome CSS (untuk ikon) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font- awesome/5.15.3/css/all.min.css">
<!--Tautan ke css-->
<link rel="stylesheet" href="style.css">
<!--Tautan ke gogle font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<!-- Font Awesome untuk ikon bintang -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#about">About </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#new">New Arrivals </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="bukutamu.php">Order Now</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- end navbar-->



<!-- Header with Full Width Image -->
<div class="container-fluid p-0">
  <div class="row">
    <div class="col-12">
      <img src="img/1.png" alt="Fashion Header" class="img-fluid w-100 mx-auto d-block">
    </div>
  </div>
</div>
<!-- End Header -->

<!--About-->
<div class="container py-5 mt-5" id="about">
  <div class="row">
    <div class="col">
      <center><h5 class="card-title">About</h5></center>
      <br>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
      consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
      proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
    <div class="col">
      <div class="card" style="width:30rem; height:20rem">
        <img src="img/10.png">
      </div>
    </div>
  </div>
  <br>
  <br>
</div>
<!--end-->

<!-- Tambahkan library AOS -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<!-- Tambahkan atribut data-aos -->
<div class="container mt-5">
    <h2 data-aos="fade-up" class="text-center">Produk Unggulan</h2>
    <p data-aos="fade-up" data-aos-delay="200" class="text-center">Tampil percaya diri dengan produk terbaik kami.</p>
</div>
<!-- Script AOS -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<!--promo-->
<div class="container my-5">
    <div class="alert alert-danger text-center" role="alert">
        <h4 class="alert-heading">Promo Spesial!</h4>
        <p>Diskon 20% untuk semua produk hingga akhir bulan ini. Gunakan kode <strong>PROMO20</strong> saat checkout.</p>
    </div>
</div>
<!--end-->


<!--Card-->
<div class="container mt-5" id="new">
    <h2 class="mb-4">New Arrivals</h2>
    <div class="row">
        <!-- Card 1 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/4.png" class="card-img-top" alt="Emma Pocket Bag">
                <div class="card-body">
                    <h5 class="card-title">Emma Pocket</h5>
                    <p class="card-text text-success fw-bold">IDR 225,000</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star-half-alt text-warning"></i>
                        <span class="text-muted ms-2">10 Reviews</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card 2 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/5.png" class="card-img-top" alt="Edith Blouse">
                <div class="card-body">
                    <h5 class="card-title">New Blouse</h5>
                    <p class="card-text text-success fw-bold">IDR 399,900</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <span class="text-muted ms-2">300 Reviews</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card 3 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/6.png" class="card-img-top" alt="Kutek Halal">
                <div class="card-body">
                    <h5 class="card-title">Minvetal Mocha</h5>
                    <p class="card-text text-success fw-bold">IDR 170,000</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i>
                        <span class="text-muted ms-2">60 Reviews</span>
                    </div>
                </div>
            </div>
        </div>

                <!-- Card 4 -->
                <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/7.png" class="card-img-top" alt="Kutek Halal">
                <div class="card-body">
                    <h5 class="card-title">Puru Kambera</h5>
                    <p class="card-text text-success fw-bold">IDR 170,000</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i>
                        <span class="text-muted ms-2">60 Reviews</span>
                    </div>
                </div>
            </div>
        </div>

                <!-- Card 5 -->
                <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/8.png" class="card-img-top" alt="Kutek Halal">
                <div class="card-body">
                    <h5 class="card-title">Pinky's</h5>
                    <p class="card-text text-success fw-bold">IDR 170,000</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i>
                        <span class="text-muted ms-2">60 Reviews</span>
                    </div>
                </div>
            </div>
        </div>

                <!-- Card 6 -->
                <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <img src="img/9.png" class="card-img-top" alt="Kutek Halal">
                <div class="card-body">
                    <h5 class="card-title"> Mocha</h5>
                    <p class="card-text text-success fw-bold">IDR 170,000</p>
                    <div>
                        <!-- Rating Bintang -->
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i>
                        <span class="text-muted ms-2">60 Reviews</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Testimoni -->
<div class="container my-5">
    <h3 class="text-center mb-4">Apa Kata Pelanggan Kami?</h3>
    <div class="row">
        <!-- Testimoni 1 -->
        <div class="col-md-4">
            <div class="card shadow-sm p-3">
                <p>"Produk berkualitas tinggi dan sangat nyaman dipakai. Pengiriman juga cepat!"</p>
                <h6 class="text-end">- Sarah</h6>
            </div>
        </div>
        <!-- Testimoni 2 -->
        <div class="col-md-4">
            <div class="card shadow-sm p-3">
                <p>"Desain kaosnya keren dan sesuai dengan tren masa kini. Recommended!"</p>
                <h6 class="text-end">- Rendy</h6>
            </div>
        </div>
        <!-- Testimoni 3 -->
        <div class="col-md-4">
            <div class="card shadow-sm p-3">
                <p>"Harga terjangkau dengan kualitas premium. Saya puas dengan pembeliannya."</p>
                <h6 class="text-end">- Bella</h6>
            </div>
        </div>
    </div>
</div>
<!--end-->


<!-- FAQ -->
<div class="container my-5">
    <h3 class="text-center mb-4">Pertanyaan yang Sering Diajukan</h3>
    <div class="accordion" id="faqAccordion">
        <!-- FAQ 1 -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Bagaimana cara memesan produk?
                </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                    Anda bisa memesan langsung melalui tombol "Order Now" atau hubungi kami via WhatsApp.
                </div>
            </div>
        </div>
        <!-- FAQ 2 -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Berapa lama pengiriman produk?
                </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                    Estimasi pengiriman adalah 2-5 hari kerja, tergantung lokasi tujuan.
                </div>
            </div>
        </div>
        <!-- FAQ 3 -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Apakah produk bisa dikembalikan?
                </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                    Ya, produk bisa dikembalikan jika tidak sesuai dengan pesanan dalam waktu 7 hari.
                </div>
            </div>
        </div>
    </div>
</div>
<!--end-->


<!-- hubungi kami-->
<div class="container text-center mt-5">
    <h3>Butuh Bantuan?</h3>
    <!-- Tombol Butuh Bantuan -->
    <a href="https://wa.me/6281375142561?text=Halo%20saya%20mau%20bertanya%20tentang%20produk%20Anda" target="_blank" class="btn btn-success btn-lg">
        <i class="fab fa-whatsapp"></i> Hubungi Kami di WhatsApp
    </a>
</div>
<br>
<br>
 <!--end-->


 <!-- Footer -->
<footer class="bg-dark text-white pt-4">
    <div class="container">
        <div class="row">
            <!-- Kolom 1: Tentang Kami -->
            <div class="col-md-4 mb-3">
                <h5>Tentang Kami</h5>
                <p>
                    Kami menyediakan kaos berkualitas dengan desain kekinian, nyaman, dan harga terjangkau. Tampil percaya diri dengan produk terbaik kami!
                </p>
            </div>

            <!-- Kolom 2: Kontak Kami -->
            <div class="col-md-4 mb-3">
                <h5>Kontak Kami</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt"></i> Jl.Setia Budi No.123, Kota Medan</li>
                    <li><i class="fas fa-phone"></i> +62 813-7514-2561</li>
                    <li><i class="fas fa-envelope"></i> info@brandkaos.com</li>
                </ul>
            </div>

            <!-- Kolom 3: Ikuti Kami -->
            <div class="col-md-4 mb-3">
                <h5>Ikuti Kami</h5>
                <a href="https://facebook.com" class="text-white me-3" target="_blank">
                    <i class="fab fa-facebook fa-2x"></i>
                </a>
                <a href="https://instagram.com" class="text-white me-3" target="_blank">
                    <i class="fab fa-instagram fa-2x"></i>
                </a>
                <a href="https://twitter.com" class="text-white" target="_blank">
                    <i class="fab fa-twitter fa-2x"></i>
                </a>
            </div>
            <center><p class="mb-0">&copy; 2024 Brand Kaos. Semua Hak Dilindungi.</p></center>
        </div>
    </div>
</footer>

<!-- Script Bootstrap dan FontAwesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<!--End about-->

