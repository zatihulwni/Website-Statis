<?php
    require_once "config.php";
    
    $nama = $ukuran_mlxl = $ukuran_2xl = $ukuran_3xl = $ukuran_4xl = $jumlah = $total_bayar = "";
    $nama_err = $ukuran_mlxl_err = $ukuran_2xl_err = $ukuran_3xl_err = $ukuran_4xl_err = "";

    $harga_mlxl= 100000;   // Harga ukuran M-L-XL
    $harga_2xl = 120000;   // Harga ukuran 2XL
    $harga_3xl = 140000;   // Harga ukuran 3XL
    $harga_4xl = 160000;   // Harga ukuran 4XL

    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
        // Validasi nama
        $input_nama = trim($_POST["nama"]);
        if (empty($input_nama)) {
            $nama_err = "Masukkan nama pelanggan.";
        } elseif (!preg_match("/^[a-zA-Z-' ]*$/", $input_nama)) {
            $nama_err = "Nama hanya boleh mengandung huruf, spasi, dan tanda hubung.";
        } else {
            $nama = $input_nama;
        }
    
        // Validasi ukuran M-L-XL
        $input_ukuran_mlxl = trim($_POST["ukuran_mlxl"]);
        $ukuran_mlxl = empty($input_ukuran_mlxl) ? 0 : (int)$input_ukuran_mlxl;
    
        // Validasi ukuran 2XL
        $input_ukuran_2xl = trim($_POST["ukuran_2xl"]);
        $ukuran_2xl = empty($input_ukuran_2xl) ? 0 : (int)$input_ukuran_2xl;
    
        // Validasi ukuran 3XL
        $input_ukuran_3xl = trim($_POST["ukuran_3xl"]);
        $ukuran_3xl = empty($input_ukuran_3xl) ? 0 : (int)$input_ukuran_3xl;
    
        // Validasi ukuran 4XL
        $input_ukuran_4xl = trim($_POST["ukuran_4xl"]);
        $ukuran_4xl = empty($input_ukuran_4xl) ? 0 : (int)$input_ukuran_4xl;
    
        // Hitung jumlah dan total bayar
        if (empty($nama_err)) {
            $jumlah = $ukuran_mlxl + $ukuran_2xl + $ukuran_3xl + $ukuran_4xl;
            $total_bayar =  ($ukuran_mlxl * $harga_mlxl) +
                            ($ukuran_2xl * $harga_2xl) +
                            ($ukuran_3xl * $harga_3xl) +
                            ($ukuran_4xl * $harga_4xl);

    
            // Simpan data ke database
            $sql = "INSERT INTO bukuu (nama, ukuran_mlxl, ukuran_2xl, ukuran_3xl, ukuran_4xl, jumlah, total_bayar) VALUES (?, ?, ?, ?, ?, ?, ?)";
            if ($stmt = mysqli_prepare($link, $sql)) {
                mysqli_stmt_bind_param($stmt, "siiiiii", $nama, $ukuran_mlxl, $ukuran_2xl, $ukuran_3xl, $ukuran_4xl, $jumlah, $total_bayar);
    
                if (mysqli_stmt_execute($stmt)) {
                    header("location: view.php");
                    exit();
                } else {
                    echo "Terjadi kesalahan saat menyimpan data. " . mysqli_error($link);
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }
    ?>
    



 
 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="bootstrap-5.1.3-dist\css\bootstrap.css">
    <link rel="stylesheet" href="fontawesome-free-6.0.0-web\css\all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Alkalami' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="style.css">
<style>
    body{
        background color: white;
        font-family: 'Alkalami';font-size: 22px;
    }
</style>
</head>
<body> 
<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="home.php#about">About </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="home.php#new">New Arrivals </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="bukutamu.php">Order Now</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- end navbar-->

    <!--Buku Tamu--->
  <div class="wrapper" id=#artikel> 
        <div class="container py-5 mt-5"> 
            <div class="row"> 
                <div class="col-md-12"> 
                    <div class="page-header"> 
                        <h2>Buku Tamu</h2> 
                    </div> 
                    <p>silahkan masukkan data anda</p> 
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group <?php echo (!empty($nama_err)) ? 'has-error' : ''; ?>">
                        <label>Nama Pembeli</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo $nama; ?>">
                        <span class="help-block"><?php echo $nama_err; ?></span>
                    </div>
                    <br>
                    <div class="form-group <?php echo (!empty($ukuran_mlxl_err)) ? 'has-error' : ''; ?>">
                        <label>Ukuran M, L, XL</label>
                        <input type="text" name="ukuran_mlxl" class="form-control" value="<?php echo $ukuran_mlxl; ?>">
                        <span class="help-block"><?php echo $ukuran_mlxl_err; ?></span>
                    </div>
                    <br>
                    <div class="form-group <?php echo (!empty($ukuran_2xl_err)) ? 'has-error' : ''; ?>">
                        <label>Ukuran 2XL</label>
                        <input type="text" name="ukuran_2xl" class="form-control" value="<?php echo $ukuran_2xl; ?>">
                        <span class="help-block"><?php echo $ukuran_2xl_err; ?></span>
                    </div>
                    <br>
                    <div class="form-group <?php echo (!empty($ukuran_3xl_err)) ? 'has-error' : ''; ?>">
                        <label>Ukuran 3XL</label>
                        <input type="text" name="ukuran_3xl" class="form-control" value="<?php echo $ukuran_3xl; ?>">
                        <span class="help-block"><?php echo $ukuran_3xl_err; ?></span>
                    </div>
                    <br>
                    <div class="form-group <?php echo (!empty($ukuran_4xl_err)) ? 'has-error' : ''; ?>">
                        <label>Ukuran 4XL</label>
                        <input type="text" name="ukuran_4xl" class="form-control" value="<?php echo $ukuran_4xl; ?>">
                        <span class="help-block"><?php echo $ukuran_4xl_err; ?></span>
                    </div>
                    

                
                       <div class="mt-3"> 
                        <input type="submit" class="btn btn-danger" value="Send Message">
                        <a href="view.php" class="btn btn-danger">View</a> 
                    </form> 
                </div> 
            </div> 
        </div> 
    </div> 
    <!--end Buku Tamu-->




</body> 
</html>