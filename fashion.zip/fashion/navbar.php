<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<link href='https://fonts.googleapis.com/css?family=Alegreya SC' rel='stylesheet'>
<style>
    body {
  font-family: 'Alegreya SC';font-size: 22px;
}
</style>
</head>
<body>

        <!-- navbar-->
<section id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="utama.php">Home</a>
  <a href="about.php">About</a>
  <a href="men.php">Men</a>
  <a href="women.php">Women</a>
  <a href="bukutamu.php">Contact</a></section>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; SWEET IN STYLE</span></a>
<script src="java.js" ></script>


</div>
</body>
</html> 
