<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About</title>
	<link href='https://fonts.googleapis.com/css?family=Alkalami' rel='stylesheet'>
	<style>
		body{
			background-image: url(img1/A5.jpg);
		}
		.about{
			font-family: 'Alkalami';font-size: 22px;
		}
	</style>
</head>
<body>
	<?php
	     include 'navbar.php';
	     ?>
<div class="about">
	<div class="row">
		<center><img src="img1/A4.jpg">
		<p>Fashion adalah bentuk ekspresi diri dan otonomi pada periode dan tempat tertentu serta dalam konteks spesifik, yang mencakup pakaian, alas kaki, gaya hidup, aksesori, riasan, gaya rambut, dan sikap tubuh. Istilah ini mengacu pada penampilan yang ditentukan oleh industri fashion sebagai tren yang sedang berlangsung. Segala sesuatu yang dianggap fashion tersedia dan dipopulerkan oleh sistem fashion (industri dan media).</p></center>
	</div>
</div>

</body>
</html>